﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace langfvn.Common
{
    public static class CommonConstaints
    {
        public static String USER_SESSION = "USER_SESSION";
    }
}